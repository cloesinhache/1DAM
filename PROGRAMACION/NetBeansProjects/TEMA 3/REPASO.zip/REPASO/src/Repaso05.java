/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

 /*ENUNCIADO:Muestra los números del 320 al 160, contando de 20 en 20 hacia atrás utilizando
un bucle while.*/
/**
 *
 * @author cloer
 */
public class Repaso05 {

    public static void main(String[] args) {

        //declaro las variables
        int i = 340;

        //hago un bucle while mientras que la i sea mayor a 160 va decrementando 20
        while (i > 160) {
            i += -20;
            System.out.println(i);

        }

    }
}
