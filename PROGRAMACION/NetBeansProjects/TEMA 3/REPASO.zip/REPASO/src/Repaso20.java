/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;

//ENUNCIADO:Igual que el ejercicio anterior pero esta vez se debe pintar una pirámide hueca.
/**
 *
 * @author cloer
 */
public class Repaso20 {

    public static void main(String[] args) {

        //declaro las variables
        int altura, blancos, relleno,internos;
        String caracter;

        //declaro el objeto lector Scanner
        Scanner lector = new Scanner(System.in);

        //Introduzco la altura y el caracter
        System.out.println("Introduzca la altura de la piramide");
        altura = lector.nextInt();
        System.out.println("Introduzca el caracter de relleno");
        caracter = lector.next();

        //inicio las variables
        blancos = altura - 1;
        relleno = 1;
        internos=0;

        //hago un for para que me genere las lineas
        for (int i = 0; i < altura-1; i++) {

            //bucle blancos
            for (int j = 0; j < blancos; j++) {
                System.out.print(" ");
            }
            
            //bucle relleno
            for (int j = 0; j < relleno; j++) {
                if(j==relleno-i-2){
                    System.out.print(" ");
                }else{
               System.out.print(caracter);
            }
            }

            //actualizo las variables
            blancos--;
            relleno += 2;

            System.out.println("");//salto de linea para que me cambie de fila

        }
        System.out.print(caracter);
        System.out.println(""); //salto de linea estetico
    }

}

